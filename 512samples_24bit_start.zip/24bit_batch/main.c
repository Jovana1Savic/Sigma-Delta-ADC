/*
 * @file main.c
 * @brief Program that continually reads 512 samples of 24-bit AD conversion results
 * from channel 0 and sends them via UART.
 *
 * @detail ADC converts signal and writes the result until the buffer is full. When
 * there's no more space left, UART begins sending all collected samples, each one
 * as three 8-bit messages. When all messages have been sent, UART is stopped and ADC
 * takes over again. Micro-controller enters low power after initializing everything
 * so all actions happen inside interrupts.
 *
 */
#include "msp430.h"
#include <stdint.h>

#define bufferSize 512

// Array that stores conversion result. buffer[0][i] contains LSB for i-th
// conversion
static uint8_t buffer[3][bufferSize];

static uint16_t producerCounter = 0;
static uint16_t consumerCounter = 0;

static uint8_t producerCurrBuff = 0;
static uint8_t consumerCurrBuff = 0;

static uint8_t PCReady = 0;
static uint8_t ADCReady = 0;

inline void initADC(){

    SD24CTL = SD24REFS;                         // Select internal reference voltage.
    SD24CCTL0  |= SD24DF | SD24IE | SD24LSBTOG; // Enable interrupt, use two's complement, 256 OSR and enable LSB toggle.

    __delay_cycles(3200);                       // Delay ~200us for 1.2V ref to settle

}

inline void startADC(){
    SD24CCTL0 |= SD24SC;                        // Set bit to start conversion
}

inline void initUART(){

    P1SEL0 |=   BIT2 | BIT3;                    // P1.2/3 eUSCI_A Function
    P1SEL1 &= ~(BIT2 | BIT3);

    UCA0CTL1 |= UCSWRST;                        // Hold eUSCI in reset
    UCA0CTL1 |= UCSSEL_2;                       // SMCLK
    UCA0BR0   = 0xAA;                           // 9600 baud
    UCA0BR1   = 0x06;
    UCA0MCTLW = 0xD600;                         // 16.384MHz/9600 = 1706.6667 (See UG)
    UCA0CTL1 &= ~UCSWRST;                       // Release from reset
    UCA0IE |= UCRXIE;                           // Enable RX interrupt.
}

void main(void) {
    WDTCTL = WDTPW | WDTHOLD;                   // Stop WDT

    initUART();
    initADC();
    startADC();

    __bis_SR_register(LPM0_bits | GIE);         // Enter LPM0 w/ interrupts
    __no_operation();                           // For debugger
}

#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=SD24_VECTOR
__interrupt void SD24_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(SD24_VECTOR))) SD24_ISR (void)
#else
#error Compiler not supported!
#endif
{
    static int16_t producerRes0;                // Lower 16 bits.
    static int16_t producerRes1;                // Higher 16 bits.

    switch (__even_in_range(SD24IV,SD24IV_SD24MEM3)) {
        case SD24IV_NONE: break;
        case SD24IV_SD24OVIFG: break;
        case SD24IV_SD24MEM0:

            producerRes1 = SD24MEM0;            // Read upper 16 bits.
            producerRes0 = SD24MEM0;            // Read lower 16 bits.

            buffer[producerCurrBuff++][producerCounter] = producerRes0;           // Byte 0.
            buffer[producerCurrBuff++][producerCounter] = producerRes0 >> 8;      // Byte 1.
            buffer[producerCurrBuff++][producerCounter++] = producerRes1 >> 8;    // Byte 2.

            producerCurrBuff = 0;
            if (producerCounter >= bufferSize) { // Buffer full. Stop writing to buffer and start UART transmission.
                producerCounter = 0;
                SD24CCTL0  &= ~SD24IE;
                if (PCReady != 0){
                    PCReady = 0;
                    ADCReady = 0;
                    UCA0IE |= UCTXIE;
                }
                else
                    ADCReady = 1;
            }

            break;

        case SD24IV_SD24MEM1: break;
        case SD24IV_SD24MEM2: break;
        case SD24IV_SD24MEM3: break;
        default: break;
    }
}


#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(USCI_A0_VECTOR))) USCI_A0_ISR (void)
#else
#error Compiler not supported!
#endif
{
    switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG)) {
        case USCI_NONE: break;
        case USCI_UART_UCRXIFG:
            PCReady = UCA0RXBUF;
            if (ADCReady != 0){
                ADCReady = 0;
                PCReady = 0;
                UCA0IE |= UCTXIE;
            }
        case USCI_UART_UCTXIFG:

            UCA0TXBUF = buffer[consumerCurrBuff++][consumerCounter];    // Send LSB of a sample first.

            if (consumerCurrBuff >= 3) {                                // Move to next sample if all bytes have been sent.

                consumerCurrBuff = 0;
                consumerCounter++;

                if (consumerCounter >= bufferSize){                     // Everything has been sent. Stop UART and start ADC again.
                    consumerCounter = 0;
                    UCA0IE &= ~UCTXIE;
                    SD24CCTL0  |= SD24IE;
                }
            }

            break;
        case USCI_UART_UCSTTIFG: break;
        case USCI_UART_UCTXCPTIFG: break;
        default: break;
    }
}

